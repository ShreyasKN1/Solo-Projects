package Elevator_D;

public class Request {
   public  int sourceFloor;
   public int destinationFloor;
   public RequestType type;

   public Request(int sourceFloor, int destinationFloor, RequestType type)
   {
    this.sourceFloor=sourceFloor;
    this.destinationFloor=destinationFloor;
    this.type=type;
   }
}
