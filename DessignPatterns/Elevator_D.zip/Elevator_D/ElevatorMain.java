package Elevator_D;

public class ElevatorMain {
    public static void main(String[] args) {
    ElevatorController evm=new ElevatorController(3);
        int steps=0;
    evm.submitRequest(new Request(1,3,RequestType.HALL_UP));
    evm.submitRequest(new Request(3,8,RequestType.HALL_UP));
    evm.submitRequest(new Request(8,4,RequestType.HALL_DOWN));
    //evm.submitRequest(new Request(8,8, RequestType.internal));

     while (steps < 20) {
            evm.stepAllElevators();
            try {
                Thread.sleep(1000);  // simulating time
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
    

}
