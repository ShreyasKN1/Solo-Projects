package Elevator_D;

public enum Direction {
    UP, DOWN, IDLE
}
