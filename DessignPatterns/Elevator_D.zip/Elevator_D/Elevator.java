package Elevator_D;

import java.util.Collections;
import java.util.TreeSet;

public class Elevator {
    public int id;
    public int currentFloor;
    public Direction direction;

    public Elevator(int id) {
            this.id = id;
            this.currentFloor = 0;
            this.direction = Direction.IDLE;
        }


    public int getCurrentFloor() { return currentFloor; }
    public Direction getDirection() { return direction; }
    public boolean isIdle() { return direction == Direction.IDLE; }

    // Requests split by direction (SCAN algo inspired)
    //up request-> ascending order
    //down request-> descending order

    private TreeSet<Integer> upRequests = new TreeSet<>();
    private TreeSet<Integer> downRequests = new TreeSet<>(Collections.reverseOrder());

    

    public synchronized void addRequest(Request request) {
         addStop(request.sourceFloor);       // pickup
    addStop(request.destinationFloor);  // drop

    // immediately decide direction if idle
    if (direction == Direction.IDLE) {
        decideDirection();
    }
    }

    private void addStop(int floor) {
          if (floor > currentFloor) {
        upRequests.add(floor);
    } else if (floor < currentFloor) {
        downRequests.add(floor);
    } else {
        stop(); // already at floor
    }
    }


    public synchronized void step() {
           if (direction == Direction.IDLE) 
            {
                decideDirection();
            }
    if (direction == Direction.UP) {
        moveUp();
    } else if (direction == Direction.DOWN) {
        moveDown();
    }
    }

    private void moveUp() {
      if (currentFloor < 9) {
        currentFloor++;  // 🔥 move happens here
    }
        if (upRequests.contains(currentFloor)) {
            upRequests.remove(currentFloor);
            stop();
        }
        if (upRequests.isEmpty()) {
            direction = downRequests.isEmpty() ? Direction.IDLE : Direction.DOWN;
        }
    }

    private void moveDown() {
       if (currentFloor>0) {
        currentFloor--;  // 🔥 move happens here
    }
        if (downRequests.contains(currentFloor)) {
            downRequests.remove(currentFloor);
            stop();
        }
        if (downRequests.isEmpty()) {
            direction = upRequests.isEmpty() ? Direction.IDLE : Direction.UP;
        }
    }

    private void decideDirection() {
        if (!upRequests.isEmpty()) direction = Direction.UP;
        else if (!downRequests.isEmpty()) direction = Direction.DOWN;
    }

    private void stop() {
        System.out.println("Elevator " + id + " stopped at floor " + currentFloor);
    }

   
}
