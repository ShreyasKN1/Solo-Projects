package Elevator_D;

public enum RequestType {
    HALL_UP,
    HALL_DOWN,
    internal
    
}
