package Elevator_D;

import java.util.ArrayList;
import java.util.List;

public class ElevatorController {

    private List<Elevator> elevators;

    public ElevatorController(int n) {
        elevators = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            elevators.add(new Elevator(i));
        }
    }

    public void submitRequest(Request request) {
        validate(request);

        Elevator best = findBestElevator(request);
        if(best==null)
        {
            throw new RuntimeException("Lol bro all r either busy or something wrong");
        }
        System.out.println("Elevator " + best.id + " at floor " + best.currentFloor + " direction " + best.direction);
        best.addRequest(request);
    }


    //first validate req

     private void validate(Request r) {
        if (r.sourceFloor < 0 || r.sourceFloor > 9 ||
            r.destinationFloor < 0 || r.destinationFloor > 9) {
            throw new IllegalArgumentException("Invalid floor");
        }

        if (r.sourceFloor == r.destinationFloor) {
            throw new IllegalArgumentException("Already at destination");
        }
    }


    private boolean isSameDirection(Elevator e, Request r) {
        if (r.type == RequestType.HALL_UP) return e.getDirection() == Direction.UP && e.getCurrentFloor()<=r.sourceFloor;
        if (r.type == RequestType.HALL_DOWN) return e.getDirection() == Direction.DOWN && e.getCurrentFloor()>=r.sourceFloor;
        return false;
    }

   


    private Elevator findBestElevator(Request request) {
        Elevator best = null;
        int minDistance = Integer.MAX_VALUE;

        for (Elevator e : elevators) {

            // 1. Idle elevator -> best case
            if (e.isIdle())  {  
            int distance = Math.abs(e.getCurrentFloor() - request.sourceFloor);
            if (distance < minDistance) {
            minDistance = distance;
            best = e;
            }
        }

            // 2. Same direction optimization
            if (isSameDirection(e, request)) {
                int distance = Math.abs(e.getCurrentFloor() - request.sourceFloor);
                if (distance < minDistance) {
                    minDistance = distance;
                    best = e;
                }
            }
        }

        if (best != null) return best;

        // 3. Fallback: nearest elevator
        if (best == null) {
            for (Elevator e : elevators) {
                int distance = Math.abs(e.getCurrentFloor() - request.sourceFloor);
                if (distance < minDistance) {
                    minDistance = distance;
                    best = e;
                }
            }
        }

        return best;
    }

    public void stepAllElevators() {
       for(Elevator E: elevators)
       {
        E.step();
       }
    }
}
