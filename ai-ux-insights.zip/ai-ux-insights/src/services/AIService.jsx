
export async function fetchAIInsights(events) {
  const prompt = `
You are a UX expert analyzing frontend interaction data.

Analyze these events and suggest UI improvements:
${JSON.stringify(events)}
`;

  const response = await fetch(
    "https://api.cloudflare.com/client/v4/accounts/put acc number here/ai/run/@cf/meta/llama-3-8b-instruct",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_CF_API_KEY}`
      },
      body: JSON.stringify({
        messages: [
          { role: "system", content: "You are a UX analytics expert." },
          { role: "user", content: prompt }
        ]
      })
    }
  );

  const data = await response.json();

  return data.result.response;
}



// export async function fetchAIInsights(events) {

//   const response = await fetch(
//     "https://api.openai.com/v1/chat/completions",
//     {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//         Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`
//       },
//       body: JSON.stringify({
//         model: "gpt-4o-mini",
//         messages: [
//           {
//             role: "system",
//             content:
//               "You are a UX expert analyzing frontend interaction data."
//           },
//           {
//             role: "user",
//             content: `Analyze these user interaction events and suggest UI improvements: ${JSON.stringify(events)}`
//           }
//         ]
//       })
//     }
//   );

//   const data = await response.json();

//   return data.choices[0].message.content;
// }





