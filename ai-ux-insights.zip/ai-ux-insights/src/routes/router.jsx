import { BrowserRouter,Routes, Route } from "react-router-dom";
import Dashboard from "../pages/Dashboard";
import LoginPage from "../pages/LoginPage";
import ProductsPage from "../pages/ProductsPages";

// //-> Dashboard.jsx home page 
// -> LoginPage.jsx
//-> ProductsPage.jsx
export default function Router(){

    return (
        <BrowserRouter>
        <Routes>
            <Route path="/" element={<Dashboard />}/>
            <Route path="/login" element={<LoginPage/>}/>
            <Route path="/products" element={<ProductsPage/>}/>
        </Routes>
        </BrowserRouter>
    )
}