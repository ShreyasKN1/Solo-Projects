export  function getSessionId() {

  let sessionId = localStorage.getItem("session-id");

  if (!sessionId) {
    sessionId = crypto.randomUUID();
    localStorage.setItem("session-id", sessionId);
  }

  return sessionId;
}