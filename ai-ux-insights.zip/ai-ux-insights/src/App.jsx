import Router from "./routes/router"
import ErrorBoundary from "./errorboundary/ErrorBoundary";
import QueryProvider from './providers/QueryProvider';
import InteractionProvider from './providers/InteractionProvider';


// const InsightsPanel = React.lazy(() =>
//   import("./features/aiInsights/InsightsPanel")
// );
function App() {
  return (
      <ErrorBoundary>
        <QueryProvider>
        <InteractionProvider>
          <Router />
      </InteractionProvider>
      </QueryProvider>
    </ErrorBoundary>
  )
}

export default App
