import { useEffect,createContext, useState, useRef } from "react";

export const InteractionContext=createContext();

export default function InteractionProvider({children})
{
    const [events,setEvents]=useState([]);

    const buffer = useRef([]);

  function trackEvent(event) {

    buffer.current.push(event);
  }

   useEffect(() => {

    const interval = setInterval(() => {

      if (buffer.current.length > 0) {
        console.log("Flushing events:", buffer.current)

        setEvents(prev => [
          ...prev,
          ...buffer.current
        ]);

        buffer.current = [];

      }

    }, 3000);

    return () => clearInterval(interval);

  }, []);

    return(
    <InteractionContext.Provider value={{ events, trackEvent }}>
      {children}
    </InteractionContext.Provider>
    )
}