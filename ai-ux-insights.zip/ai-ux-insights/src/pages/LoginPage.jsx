import { Link } from "react-router-dom";
import LoginForm from "../components/LoginForm";
import { useEffect } from "react";
import useTrackInteraction from "../hooks/usetrackInteraction";


export default function LoginPage() {

const track = useTrackInteraction("login-page");

  useEffect(() => {
    track("page-view");
  }, []);

  return (
     <div className="login-container">

      <div className="login-card">

        <h1 className="login-header">Login</h1>

      <Link to="/">
        ← Back to Dashboard
      </Link>

      <div style={{ marginTop: "20px" }}>
        <LoginForm />
      </div>
       
      </div>

    </div>
  );
}