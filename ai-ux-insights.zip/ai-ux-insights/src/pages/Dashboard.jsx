import { Link } from "react-router-dom";
import InsightsPanel from "../features/aiInsights/InsightsPanel";
import usePageTracking from "../hooks/usePageTracking";

export default function Dashboard() {

   usePageTracking("dashboard");

  return (
    <div className="container">

      <h1>AI UX Analytics Dashboard</h1>

      <nav>
        <Link to="/login">
          Login Page
        </Link>

        <Link to="/products">
          Products Page
        </Link>
      </nav>

      <InsightsPanel />

    </div>
  );
}