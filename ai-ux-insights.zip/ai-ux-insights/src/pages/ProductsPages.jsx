import ProductCard from "../components/ProductCard";
import { Link } from "react-router-dom";
import usePageTracking from "../hooks/usePageTracking";
import Trackable from "../components/trackable";


export default function ProductsPage(){

   usePageTracking("products-page");

  const products = [
    { id: 1, name: "iPhone 15", price: 1200 },
    { id: 2, name: "MacBook Pro", price: 2500 },
    { id: 3, name: "AirPods Pro", price: 250 },
    { id: 4, name: "iPad Air", price: 700 },
    { id: 5, name: "Apple Watch", price: 400 },
    { id: 6, name: "Samsung S24", price: 1100 },
    { id: 7, name: "Dell XPS", price: 1800 },
    { id: 8, name: "Sony Headphones", price: 350 },
    { id: 9, name: "Logitech Mouse", price: 80 },
    { id: 10, name: "Mechanical Keyboard", price: 150 }
  ];

  return (
    <div>

      <h1 className="header">Products</h1>

      <Link to="/">
        ← Back to Dashboard
      </Link>

      <div className="products-grid">

        
          {products.map(product => (

          <Trackable
            componentId={`product-${product.id}`}
            key={product.id}
          >

            <ProductCard product={product} />

          </Trackable>
          ))}

      </div>

    </div>
  );

}