import { useContext } from "react";
import { InteractionContext } from "../../providers/InteractionProvider";
import UseAIInsights from "../../hooks/useAIInsights";

export default function InsightsPanel(){
 const { events } = useContext(InteractionContext);

  const { data, isLoading } = UseAIInsights(events);

  if (isLoading) return <div>Analyzing your page...</div>;

  return (
    <div className="insights">
      <h2>AI Suggestions..</h2>
     <ul>
       {data?.split("\n").map((line, index) => (
          <li key={index}>{line}</li>
        ))}
     </ul>
    </div>
  );
}