import { useContext } from "react";
import { InteractionContext } from "../providers/InteractionProvider";
import { useLocation } from "react-router-dom"
import  { getSessionId } from "../utils/session";


export default function useTrackInteraction(componentId){
 const { trackEvent } = useContext(InteractionContext);
  const location = useLocation();

  function track(eventType, metadata={}) {
    trackEvent({
      component: componentId,
      event: eventType,
      page: location.pathname,
      sessionId: getSessionId(),
      metadata,
      timestamp: Date.now()
    }
  );
  }

  return track;
}