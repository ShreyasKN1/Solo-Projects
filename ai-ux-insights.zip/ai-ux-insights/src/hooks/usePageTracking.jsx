import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import useTrackInteraction from "./usetrackInteraction";

export default function usePageTracking(componentId) {

  const track = useTrackInteraction(componentId);
  const location = useLocation();

  useEffect(() => {

    track("page-view");

  }, [location.pathname]);
}