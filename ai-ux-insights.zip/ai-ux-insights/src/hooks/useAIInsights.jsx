import { useQuery } from "@tanstack/react-query";
import {fetchAIInsights} from "../services/AIService"



export default function UseAIInsights(events) {

  return useQuery({
    queryKey: ["ai-insights", events],
    queryFn: () => fetchAIInsights(events),
    enabled: events.length > 0,
    staleTime: 60000
  });

}