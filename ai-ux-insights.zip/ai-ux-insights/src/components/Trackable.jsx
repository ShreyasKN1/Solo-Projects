import useTrackInteraction from "../hooks/usetrackInteraction";

export default function Trackable({ componentId, children }) {

  const track = useTrackInteraction(componentId);

  return (
    <div
      onClick={() => track("click")}
      onMouseEnter={() => track("hover")}
    >
      {children}
    </div>
  );
}