import useTrackInteraction from "../hooks/usetrackInteraction";


export default function LoginForm(){

  const track=useTrackInteraction("login-form");

  return (
    <form onSubmit={() => track("submit")}>
      <input
        placeholder="Email"
        onFocus={() => track("focus-email")}
      />

      <input
        type="password"
        placeholder="Password"
        onFocus={() => track("focus-password")}
      />

      <button onClick={() => track("login-click")}>
        Login
      </button>
    </form>
  );
}