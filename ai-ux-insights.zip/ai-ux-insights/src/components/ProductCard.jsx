import useTrackInteraction from "../hooks/usetrackInteraction";

export default function ProductCard({ product }) {

  const track = useTrackInteraction(`product-${product.id}`);

  return (
    <div className="product-card"
    >
      <h3>{product.name}</h3>

      <p>${product.price}</p>

      <button onClick={() => track("view-product")}>
        View
      </button>

      <button onClick={() => track("add-to-cart")}>
        Add to Cart
      </button>
    </div>
  );
}