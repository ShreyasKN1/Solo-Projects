
1. npm install
2. npm run dev

Features:
- Pagination
- TanStack Query useQuery
- useMutation
- Optimistic updates
