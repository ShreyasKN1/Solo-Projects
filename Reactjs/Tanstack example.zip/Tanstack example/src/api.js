
import axios from "axios"

export const fetchProducts = async (page) => {
  const res = await axios.get(
    `https://dummyjson.com/products?limit=5&skip=${(page - 1) * 5}`
  )

  return res.data.products.map(p => ({
    ...p,
    enabled: Math.random() > 0.5 // used for test purpose 
  }))
}

export const toggleProduct = async () =>
                  new Promise(resolve => setTimeout(resolve, 400))
