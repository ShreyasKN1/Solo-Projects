
import React from "react"
import ReactDOM from "react-dom/client"
import App from "./App"
import "./styles.css"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60000,//cachedtime can be provided 
      //we can refecthIntervals instead of manual refresh auto one
      refetchOnWindowFocus: false
      //data should not be refetched on window focus othewise stale data will be sent back
    }
  }
})

ReactDOM.createRoot(document.getElementById("root")).render(
  <QueryClientProvider client={queryClient}>
    <App />
  </QueryClientProvider>


)
