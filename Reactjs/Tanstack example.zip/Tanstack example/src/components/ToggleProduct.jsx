
import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toggleProduct } from "../api"

export default function ToggleProduct({ product }) {

  
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: toggleProduct,

    onMutate: async () => {

      //avoid overriding-> if old finishes late and the recent gets oveeriden.
      await queryClient.cancelQueries(["products"])


      //take a snapshot of data here and can be rollbacked
      const previous = queryClient.getQueriesData(["products"])


      //setQueries-> for immediate reflection directly from cache no reftch no rerendering.
      queryClient.setQueriesData(["products"], old =>
        old?.map(p =>
          p.id === product.id? { ...p, enabled: !p.enabled }: p
        )
      )

      return { previous }
    },


    //on error-> show previous data itself
    onError: (_, __, context) => {
      context.previous.forEach(([key, data]) => {
        queryClient.setQueryData(key, data)
      })
    },

    onSettled: () => {
      //memory will still have data, refetch happens if the product comp is up otherwise old data visible
      queryClient.invalidateQueries(["products"])
    }
  })

  return (
    <button onClick={() => mutation.mutate()}>
      Toggle
    </button>
  )
}
