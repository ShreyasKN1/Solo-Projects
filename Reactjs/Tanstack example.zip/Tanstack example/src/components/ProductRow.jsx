
import ToggleProduct from "./ToggleProduct"

export default function ProductRow({ product }) {
  return (
    <div className="row">
      <span>{product.title}</span>
      <span className={product.enabled ? "on" : "off"}>
        {product.enabled ? "ENABLED" : "DISABLED"}
      </span>
      <ToggleProduct product={product} />
    </div>
  )
}
