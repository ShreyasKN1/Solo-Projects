
import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { fetchProducts } from "../api"
import ProductRow from "./ProductRow"

export default function ProductList() {
  const [page, setPage] = useState(1)

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ["products", page],
    queryFn: ({queryKey:[,page]}) => fetchProducts(page),
    keepPreviousData: true
  })

  if (isLoading) return "Loading..."

  return (
    <div>
      {data.map(p => (
        <ProductRow key={p.id} product={p} />
      ))}

      <div className="pager">
        <button onClick={() => setPage(old => Math.max(old - 1, 1))}>Prev</button>
        <button onClick={() => setPage(old => old + 1)}>Next</button>
        {isFetching && <span> Fetching...</span>}
      </div>
    </div>
  )
}
