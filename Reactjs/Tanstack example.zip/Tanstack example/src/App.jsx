
import ProductList from "./components/ProductList"

export default function App() {
  return (
    <div className="app">
      <h2>Product Catalog</h2>
      <ProductList />
    </div>
  )
}
